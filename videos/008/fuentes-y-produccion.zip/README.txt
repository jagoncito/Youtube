Fuentes y producción de008. Los archivos para subir a YouTube son el MP4, miniatura.jpg y publicacion.txt, fuera de este ZIP.

Requisitos: Python3.12, FFmpeg7.1.5 con libass/libx264, dependencias de produccion/requirements.txt y sfizz compilado con produccion/build_sfizz.sh. MXL originales y PDF de consulta en partitura/. La creación musical utiliza el MXL; los PDF no son una edición crítica.

Desde esta carpeta extraída, para reconstruir en un directorio temporal:
python -m pip install -r produccion/requirements.txt
python partitura/extract_score.py --source partitura/original --out /tmp/s008/score
python produccion/download_instruments.py --manifest instrumentos/instrument-sources.json --dest /tmp/s008/samples
python produccion/prepare_runtime_maps.py --samples /tmp/s008/samples
python produccion/create_performance.py --score /tmp/s008/score --samples /tmp/s008/samples --calibration instrumentos/instrument-calibration.json --out /tmp/s008/audio
bash produccion/build_sfizz.sh /tmp/s008/engine
Para cadaN=1,2,3,4:
python produccion/render_orchestra.py --events /tmp/s008/audio/movement-N-performance.json --instrument-map /tmp/s008/audio/instrument-map.json --samples /tmp/s008/samples --library /tmp/s008/engine/sfizz/build/library/lib/libsfizz.so --output /tmp/s008/audio/movement-N.float.wav
python produccion/master_program.py --input-dir /tmp/s008/audio --output /tmp/s008/beethoven-symphony-no1.wav
python produccion/animar_pasaje.py --image ../imagen.png --config datos/pasaje-parametros.json --output /tmp/s008/escena-60s.mp4
python produccion/montar_video.py --scene /tmp/s008/escena-60s.mp4 --audio /tmp/s008/beethoven-symphony-no1.wav --master /tmp/s008/beethoven-symphony-no1.mastering.json --output /tmp/s008/beethoven-symphony-no1.mp4
python produccion/verify_delivery.py --root /tmp/s008 --score /tmp/s008/score --performance /tmp/s008/audio --out /tmp/s008/verification.json

Los MIDI archivados usan pistas/puertos separados; la mezcla final utiliza eventos temporizados y los mapas SFZ indicados. Los datos de datos/ conservan la realización entregada y las comprobaciones. No se incluyen WAV de pruebas ni muestras aisladas. No se han programado tareas ni publicado en YouTube.
