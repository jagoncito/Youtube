#!/usr/bin/env python3
"""Extract complete Op.21 notation, then explicitly unfold its musical form.

Underlying score is CC0; research lyrics/colors are not interpretation inputs.
Original annotated source archives retain their own separate notices.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter,defaultdict
import argparse,hashlib,json,zipfile,xml.etree.ElementTree as ET

STEP={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
TYPE={'whole':4,'half':2,'quarter':1,'eighth':.5,'16th':.25,'32nd':.125,'64th':.0625,'128th':.03125}

def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def node(n):return {'tag':n.tag,'text':n.text.strip() if n.text else None,'attributes':{k:v for k,v in n.attrib.items() if k not in ('color','default-x','default-y','relative-x','relative-y')}}
def instrument(name):
 for marker,key in [('Flute','flute'),('Oboe','oboe'),('Clarinet','clarinet'),('Bassoon','bassoon'),('Horn','horn'),('Trumpet','trumpet'),('Timpani','timpani'),('Violin','violin'),('Viola','viola'),('Violoncello','cello'),('Contrabass','bass')]:
  if marker in name:return key
 raise ValueError(name)

def read_archive(path):
 with zipfile.ZipFile(path) as z:
  container=ET.fromstring(z.read('META-INF/container.xml'))
  rf=next(n for n in container.iter() if n.tag.endswith('rootfile'))
  name=rf.get('full-path')
  return ET.fromstring(z.read(name)),name

def parse_movement(path,movement):
 root,inside=read_archive(path)
 names={p.get('id'):p.findtext('part-name') for p in root.findall('part-list/score-part')}
 rawnotes=[];directions=[];measures_by_part={};partmeta=[];rawindex=0;all_note_tags=0;rests=0
 for part in root.findall('part'):
  pid=part.get('id');name=names[pid];inst=instrument(name)
  divisions=Fraction(1);transpose=0;diatonic=0;octave_transpose=0;meter=(4,4);keyfifths=0
  barrows=[];written_q=Fraction(0);part_transpositions=[]
  for measure_index,measure in enumerate(part.findall('measure')):
   bar=measure.get('number');pos=Fraction(0);extent=Fraction(0);laststart=Fraction(0)
   starts_repeat=False;ends_repeat=False;ending=None;endingstop=None;dc=False;fine=False
   noteids=[]
   for c in measure:
    if c.tag=='attributes':
     if c.find('divisions') is not None:divisions=Fraction(c.findtext('divisions'))
     if c.find('time') is not None:
      tm=c.find('time');meter=(int(tm.findtext('beats')),int(tm.findtext('beat-type')))
     if c.find('key/fifths') is not None:keyfifths=int(c.findtext('key/fifths'))
     if c.find('transpose') is not None:
      tr=c.find('transpose');transpose=int(tr.findtext('chromatic','0'));diatonic=int(tr.findtext('diatonic','0'));octave_transpose=int(tr.findtext('octave-change','0'))
      part_transpositions.append({'bar':bar,'chromatic':transpose,'diatonic':diatonic,'octave_change':octave_transpose,'sounding_semitones':transpose+12*octave_transpose})
    elif c.tag=='backup':pos-=Fraction(c.findtext('duration'))/divisions;assert pos>=0,(movement,pid,bar,'negativebackup')
    elif c.tag=='forward':pos+=Fraction(c.findtext('duration'))/divisions;extent=max(extent,pos)
    elif c.tag=='direction':
     offset=Fraction(c.findtext('offset','0'))/divisions
     sounds=[dict(s.attrib)for s in c.findall('sound')]
     dc|=any(s.get('dacapo')=='yes'for s in sounds);fine|=any(s.get('fine')=='yes'for s in sounds)
     types=[]
     for dt in c.findall('direction-type'):
      for item in dt:
       if item.tag=='rehearsal':continue # research section labels are not used
       if item.tag=='dynamics':types.append({'tag':'dynamics','values':[n.tag for n in item]})
       elif item.tag=='metronome':types.append({'tag':'metronome','children':[node(n)for n in item]})
       else:types.append(node(item))
     directions.append({'movement':movement,'part_id':pid,'part_name':name,'bar':bar,'measure_index':measure_index,'local_quarter':float(pos+offset),'written_quarter':float(written_q+pos+offset),'voice':c.findtext('voice',''),'staff':c.findtext('staff','1'),'types':types,'sound':sounds})
    elif c.tag=='barline':
     rep=c.find('repeat');en=c.find('ending')
     if rep is not None:
      starts_repeat|=rep.get('direction')=='forward';ends_repeat|=rep.get('direction')=='backward'
     if en is not None:
      if en.get('type')=='start':ending=en.get('number')
      else:endingstop={'number':en.get('number'),'type':en.get('type')}
    elif c.tag=='note':
     all_note_tags+=1
     grace=c.find('grace') is not None;chord=c.find('chord') is not None
     duration=Fraction(c.findtext('duration','0'))/divisions
     start=laststart if chord else pos
     if not chord:laststart=start
     if c.find('rest') is not None:rests+=1
     elif c.find('pitch') is not None:
      pitch=c.find('pitch');step=pitch.findtext('step');alter=Fraction(pitch.findtext('alter','0'));octave=int(pitch.findtext('octave'))
      assert alter.denominator==1,(movement,pid,bar,'microtone')
      written_pitch=12*(octave+1)+STEP[step]+int(alter);sounding=written_pitch+transpose+12*octave_transpose
      rawindex+=1;sid=f'm{movement}-{pid}-n{rawindex}'
      arts=[n.tag for a in c.findall('notations/articulations')for n in a]
      slurs=[dict(s.attrib)for s in c.findall('notations/slur')]
      ornaments=[node(n)for a in c.findall('notations/ornaments')for n in a]
      fermatas=[node(n)for n in c.findall('notations/fermata')]
      ties=sorted(set([n.get('type')for n in c.findall('tie')]+[n.get('type')for n in c.findall('notations/tied')]))
      nominal=Fraction(str(TYPE.get(c.findtext('type'),0)))
      for j,_ in enumerate(c.findall('dot'),1):nominal+=Fraction(str(TYPE.get(c.findtext('type'),0)))/(2**j)
      row={'source_id':sid,'source_index':rawindex,'movement':movement,'part_id':pid,'part_name':name,'instrument':inst,'bar':bar,'measure_index':measure_index,'local_quarter':float(start),'written_quarter':float(written_q+start),'duration_quarters':float(duration),'written_pitch':written_pitch,'written_step':step,'written_alter':int(alter),'written_octave':octave,'sounding_pitch':sounding,'pitch':sounding,'transpose_semitones':transpose+12*octave_transpose,'voice':c.findtext('voice','1'),'staff':c.findtext('staff','1'),'key_fifths':keyfifths,'grace':grace,'grace_nominal_quarters':float(nominal)if grace else 0.,'grace_attributes':dict(c.find('grace').attrib)if grace else None,'chord':chord,'ties':ties,'articulations':arts,'slurs':slurs,'ornaments':ornaments,'fermatas':fermatas,'note_type':c.findtext('type'),'dots':len(c.findall('dot'))}
      rawnotes.append(row);noteids.append(sid)
     else:raise ValueError((movement,pid,bar,'unpitchednote'))
     if not chord and not grace:pos+=duration
     extent=max(extent,start+duration,pos)
   barrows.append({'index':measure_index,'bar':bar,'written_start_quarter':float(written_q),'actual_quarters':float(extent),'nominal_quarters':meter[0]*4/meter[1],'meter':list(meter),'key_fifths':keyfifths,'start_repeat':starts_repeat,'end_repeat':ends_repeat,'ending_start':ending,'ending_stop':endingstop,'dacapo':dc,'fine':fine,'note_ids':noteids})
   written_q+=extent
  measures_by_part[pid]=barrows
  partmeta.append({'id':pid,'name':name,'instrument':inst,'transpositions':part_transpositions,'written_measures':len(barrows),'written_quarter_beats':float(written_q),'pitched_written_notes':sum(n['part_id']==pid for n in rawnotes)})
 # Align all18parts, including the actual pickup/partial measures.
 first=measures_by_part['P1'];alignment=[]
 for pid,bars in measures_by_part.items():
  assert len(bars)==len(first),(movement,pid,'measurecount')
  for a,b in zip(first,bars):
   if abs(a['actual_quarters']-b['actual_quarters'])>1e-8:alignment.append({'part':pid,'bar':a['bar'],'reference':a['actual_quarters'],'part_length':b['actual_quarters']})
 if alignment:raise AssertionError(('Partalignmentmismatch',movement,alignment[:8]))
 return root,rawnotes,directions,first,partmeta,{'all_note_tags':all_note_tags,'rests':rests,'pitched_written_notes':len(rawnotes),'grace_notes':sum(n['grace']for n in rawnotes),'part_alignment':'passed'}

def form(movement,bars):
 """Explicitly map this edition's repeat and da-capo notation, audited below."""
 number_to_index={int(b['bar']):i for i,b in enumerate(bars)}
 assert len(number_to_index)==len(bars)
 def span(a,b):return [number_to_index[j]for j in range(a,b+1)]
 if movement==1:
  assert bars[number_to_index[13]]['start_repeat']and bars[number_to_index[109]]['end_repeat']
  assert bars[number_to_index[108]]['ending_start']=='1'and bars[number_to_index[110]]['ending_start']=='2'
  seq=span(1,109)+span(13,107)+span(110,300)
  explanation='Opening1–12; first exposition13–109 including ending1(108–109); repeat13–107 then ending2(110–111); continuation112–300.'
 elif movement==2:
  assert not any(b['start_repeat']or b['end_repeat']or b['dacapo']for b in bars)
  seq=span(1,196);explanation='All196measures once: this selected source contains no repeat barlines or da-capo marks in movementII.'
 elif movement==3:
  assert [int(b['bar'])for b in bars if b['end_repeat']]==[9,81,106,141]
  assert bars[number_to_index[141]]['dacapo']and bars[number_to_index[81]]['fine']
  seq=span(1,9)*2+span(10,81)*2+span(82,106)*2+span(107,141)*2+span(1,81)
  explanation='Minuet1–9twice and10–81twice; Trio82–106twice and107–141twice; Menuetto daCapo1–81once toFine, using customary no-new-repeats da-capo realization.'
 elif movement==4:
  assert bars[number_to_index[8]]['start_repeat']and bars[number_to_index[97]]['end_repeat']
  assert bars[number_to_index[96]]['ending_start']=='1'and bars[number_to_index[98]]['ending_start']=='2'
  seq=span(1,97)+span(8,95)+span(98,305)
  explanation='Adagio1–7; exposition8–97with ending1(96–97); repeat8–95then ending2(98); continuation99–305.'
 else:raise ValueError(movement)
 return seq,explanation

def expand(movement,raw,directions,bars,order):
 bybar=defaultdict(list);dirbar=defaultdict(list)
 for n in raw:bybar[n['measure_index']].append(n)
 for d in directions:dirbar[d['measure_index']].append(d)
 unfolded=[];expanded_dirs=[];timeline=[];q=0.;visits=Counter()
 for occurrence,idx in enumerate(order,1):
  bar=bars[idx];visits[idx]+=1
  timeline.append({'occurrence':occurrence,'measure_index':idx,'bar':bar['bar'],'visit':visits[idx],'start_quarter':q,'duration_quarters':bar['actual_quarters'],'meter':bar['meter']})
  for n in bybar[idx]:
   e=dict(n);e.update({'id':f"{n['source_id']}-o{occurrence}",'onset_quarter':q+n['local_quarter'],'main_quarter':q+n['local_quarter'],'gate_quarters':n['duration_quarters'],'occurrence':occurrence,'bar_visit':visits[idx],'grace_quarter':0.})
   unfolded.append(e)
  for d in dirbar[idx]:
   e=dict(d);e.update({'quarter':q+d['local_quarter'],'occurrence':occurrence,'bar_visit':visits[idx]});expanded_dirs.append(e)
  q+=bar['actual_quarters']
 # Grace ordering is explicit; its printed value does not advance the clock.
 groups=defaultdict(list)
 for e in unfolded:
  if e['grace']:groups[e['part_id'],e['voice'],e['occurrence'],e['main_quarter']].append(e)
 for group in groups.values():
  total=sum(n['grace_nominal_quarters']for n in group);offset=-total
  for e in group:e['grace_quarter']=offset;e['grace_rank']=group.index(e);e['grace_count']=len(group);offset+=e['grace_nominal_quarters']
 # Resolve tied continuations only within a source part/voice/staff/pitch.
 active={};anchors=[];continuations=[];unmatched=[]
 for e in sorted(unfolded,key=lambda e:(e['onset_quarter'],e['grace_quarter'],e['part_id'],e['source_index'])):
  key=(e['part_id'],e['voice'],e['staff'],e['pitch'])
  if 'stop'in e['ties']:
   previous=active.get(key)
   if previous is None:unmatched.append({'id':e['id'],'reason':'tie-stop without start'});continue
   end=e['onset_quarter']+e['duration_quarters'];previous['gate_quarters']=end-previous['onset_quarter'];previous['duration_quarters']=previous['gate_quarters'];previous['tie_chain'].append(e['id']);previous['source_ids'].append(e['source_id']);continuations.append({'id':e['id'],'anchor_id':previous['id']})
   if 'start'not in e['ties']:del active[key]
  else:
   a=dict(e);a['source_ids']=[e['source_id']];a['tie_chain']=[e['id']];anchors.append(a)
   if 'start'in e['ties']:active[key]=a
 if active:unmatched.extend({'id':e['id'],'reason':'unclosed tie-start'}for e in active.values())
 assert not unmatched,(movement,unmatched[:10])
 # Simultaneous printed unisons within one part are one physical source attack.
 uniq={};unisons=[]
 for e in anchors:
  key=(e['part_id'],round(e['onset_quarter'],8),round(e['grace_quarter'],8),e['pitch'])
  if key in uniq:
   prior=uniq[key];prior['source_ids'].extend(e['source_ids']);prior['tie_chain'].extend(e['tie_chain']);prior['gate_quarters']=max(prior['gate_quarters'],e['gate_quarters']);prior['duration_quarters']=prior['gate_quarters'];unisons.append({'id':e['id'],'anchor_id':prior['id']})
  else:uniq[key]=e
 notes=sorted(uniq.values(),key=lambda e:(e['onset_quarter'],e['grace_quarter'],int(e['part_id'][1:]),e['source_index']))
 assert len(unfolded)==len(notes)+len(continuations)+len(unisons)
 audit={'unfolded_pitched_written_notes':len(unfolded),'source_note_anchors':len(notes),'tied_continuations':len(continuations),'simultaneous_unisons':len(unisons),'tie_continuations':continuations,'unison_consolidations':unisons,'unexplained_omissions':[],'unmatched_ties':[],'grace_attacks':sum(n['grace']for n in notes),'instrument_parts':18,'expanded_measure_occurrences':len(order),'total_quarters':q,'notes_by_part':dict(Counter(e['part_id']for e in notes)),'ornament_tags':dict(Counter(o['tag']for n in notes for o in n['ornaments']))}
 return notes,expanded_dirs,timeline,audit

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=Path(__file__).parent/'original');ap.add_argument('--out',type=Path,default=Path(__file__).parent);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 summary={'schema':'jagoncito-full-orchestral-score/1','work':'Beethoven SymphonyNo.1 inCmajorOp.21','source_repository':'https://github.com/MarkGotham/Hauptstimme','source_revision':'8f677853c45b74ca0afcd79677e5379c06c82354','score_license':'CC0 1.0Universal','annotations_license_as_declared':'CC-By-SA (versionunspecified inREADME/MXL)','annotation_handling':'Researchlyrics,redcolorsandanalyticalrehearsals are not performance inputs. Sourcearchives retain originalnotices.','source_declared_historical_reference':'IMSLP #13842; no independent historicalfacsimile collation performed','movements':[]}
 for mv in range(1,5):
  path=a.source/f'Beethoven_Op.21_{mv}.mxl';root,raw,dirs,bars,parts,rawaudit=parse_movement(path,mv);order,reason=form(mv,bars);notes,expanded,timeline,audit=expand(mv,raw,dirs,bars,order)
  dump(a.out/f'movement-{mv}-source-notes.json',raw);dump(a.out/f'movement-{mv}-notes.json',notes);dump(a.out/f'movement-{mv}-directions.json',expanded)
  structure={'movement':mv,'title':root.findtext('movement-title'),'parts':parts,'written_bars':bars,'play_order':timeline,'repeat_realization':reason,'total_quarters':audit['total_quarters']}
  dump(a.out/f'movement-{mv}-structure.json',structure);dump(a.out/f'movement-{mv}-validation.json',dict(rawaudit,**audit))
  summary['movements'].append({'movement':mv,'title':root.findtext('movement-title'),'source_file':str(path.name),'source_sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'source_imslp_reference':root.findtext('identification/source'),'written_measures':len(bars),'expanded_measure_occurrences':len(order),'total_quarters':audit['total_quarters'],'source_pitched_notes':len(raw),'source_note_anchors':len(notes),'graces':audit['grace_attacks'],'part_count':len(parts),'repeat_realization':reason})
  print(json.dumps(summary['movements'][-1]),flush=True)
 dump(a.out/'score-validation.json',summary)
if __name__=='__main__':main()
