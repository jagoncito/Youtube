#!/usr/bin/env python3
"""Render a new scored orchestral movement through isolated sfizz sample maps.

One instance per part/articulation, a shared event timeline, native sample/key
maps and documented articulation envelopes. No finished recording is an input.
Part expression is a smooth amplitude envelope, not a claimed timbral crossfade.
"""
from pathlib import Path
import argparse,ctypes as C,hashlib,json,math,re,time
import numpy as np
from scipy.io import wavfile

class OrchestraEngine:
 def __init__(self,path):
  self.lib=C.CDLL(str(path));P=C.c_void_p;I=C.c_int;F=C.c_float
  bindings=[('create_synth',P,[]),('free',None,[P]),('load_string',C.c_bool,[P,C.c_char_p,C.c_char_p]),('set_sample_rate',None,[P,F]),('set_samples_per_block',None,[P,I]),('set_num_voices',None,[P,I]),('enable_freewheeling',None,[P]),('set_sample_quality',None,[P,I,I]),('send_note_on',None,[P,I,I,I]),('send_note_off',None,[P,I,I,I]),('send_cc',None,[P,I,I,I]),('render_block',None,[P,C.POINTER(C.POINTER(F)),I,I]),('get_num_regions',I,[P]),('get_num_preloaded_samples',C.c_size_t,[P])]
  for name,rest,args in bindings:
   f=getattr(self.lib,'sfizz_'+name);f.restype=rest;f.argtypes=args;setattr(self,name,f)

 def add_part(self,mix,spec,part,artic,events,config,sfz,block=2048):
  sr=spec['sample_rate'];L=self;s=L.create_synth();frames=len(mix)
  original=sfz.read_text();text=original.replace('\\','/')
  release=config.get('release_seconds',.25)
  if release is not None:text=re.sub(r'(?m)ampeg_release=[^\s]+',f'ampeg_release={release}',text)
  # Sustain loops, ranges and tuning are not invented by this renderer. Any
  # source-map adaptation belongs to the separate documented instrument audit.
  try:
   L.set_sample_rate(s,sr);L.set_samples_per_block(s,block);L.set_num_voices(s,256);L.enable_freewheeling(s);L.set_sample_quality(s,1,8)
   if not L.load_string(s,str(sfz).encode(),text.encode()):raise RuntimeError(f'Cannot load {sfz}')
   regions=L.get_num_regions(s);samples=L.get_num_preloaded_samples(s)
   if not regions or not samples:raise RuntimeError(f'Empty {sfz}')
   begin=max(0,int((min(e['start'] for e in events)-.10)*sr)//block*block)
   end=min(frames,math.ceil((max(e['start']+e['duration'] for e in events)+max(1.2,float(release or 1.2))*2)*sr))
   rows=[(begin,0,'cc',7,100),(begin,0,'cc',10,64),(begin,0,'cc',11,127)]
   for e in events:
    on=round(e['start']*sr);off=round((e['start']+e['duration'])*sr)
    assert 0<=on<off<frames,e
    rows.extend([(on,2,'on',e['pitch'],e['velocity']),(off,1,'off',e['pitch'],0)])
   rows.sort();left=np.zeros(block,np.float32);right=np.zeros(block,np.float32)
   ptrs=(C.POINTER(C.c_float)*2)(left.ctypes.data_as(C.POINTER(C.c_float)),right.ctypes.data_as(C.POINTER(C.c_float)))
   curve=spec.get('expression_curves',{}).get(part,[[0,1],[frames/sr,1]])
   ct=np.array([x[0] for x in curve]);cv=np.array([x[1] for x in curve]);idx=0
   gain=10**(config.get('gain_db',0)/20);pan=config.get('pan',0);width=config.get('width',.4)
   peak=0.;energy=0.;leftenergy=0.;rightenergy=0.;counted=0;activeframecount=0
   for start in range(begin,end,block):
    count=min(block,end-start)
    while idx<len(rows) and rows[idx][0]<start+count:
     pos,_,kind,p1,p2=rows[idx];getattr(L,{'on':'send_note_on','off':'send_note_off','cc':'send_cc'}[kind])(s,max(0,pos-start),int(p1),int(p2));idx+=1
    L.render_block(s,ptrs,2,count)
    a=left[:count];b=right[:count]
    assert np.isfinite(a).all() and np.isfinite(b).all(),(part,artic,start)
    mid=(a+b)*.5;side=(a-b)*.5*width
    env=np.interp((start+np.arange(count))/sr,ct,cv)*gain
    lo=(mid+side)*env*math.sqrt(1-pan);ro=(mid-side)*env*math.sqrt(1+pan)
    mix[start:start+count,0]+=lo;mix[start:start+count,1]+=ro
    peak=max(peak,float(np.max(np.abs(lo))),float(np.max(np.abs(ro))))
    le=float(lo@lo);right_e=float(ro@ro);energy+=le+right_e;leftenergy+=le;rightenergy+=right_e;counted+=count*2
    activeframecount+=int(np.count_nonzero(np.maximum(np.abs(lo),np.abs(ro))>1e-5))
   assert idx==len(rows),(part,artic,len(rows)-idx)
   return {'part':part,'articulation':artic,'source_map':sfz.name,'source_map_sha256':hashlib.sha256(sfz.read_bytes()).hexdigest(),'musical_events':len(events),'regions':regions,'loaded_samples':samples,'render_window_seconds':[begin/sr,end/sr],'peak':peak,'render_window_rms':math.sqrt(energy/max(counted,1)),'program_energy':energy,'left_energy':leftenergy,'right_energy':rightenergy,'audible_frames_above_minus100':activeframecount,'mix':config,'expression':'Part-local smooth amplitude envelope plus sampled velocity layers; no timbral crossfade claimed','source_attack_unchanged':True,'release_override_seconds':release,'sustain_loops_added_by_renderer':False}
  finally:L.free(s)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--events',type=Path,required=True);ap.add_argument('--instrument-map',type=Path,required=True);ap.add_argument('--samples',type=Path,required=True);ap.add_argument('--library',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--preview-seconds',type=float)
 a=ap.parse_args();spec=json.loads(a.events.read_text());maps=json.loads(a.instrument_map.read_text());sr=spec['sample_rate'];duration=spec['duration'];events=spec['events']
 if a.preview_seconds:
  duration=min(duration,a.preview_seconds);events=[e for e in events if e['start']+.01<duration]
  events=[{**e,'duration':min(e['duration'],duration-e['start']-.001)} for e in events]
 frames=round(duration*sr);mix=np.zeros((frames,2),np.float32);engine=OrchestraEngine(a.library);reports=[];began=time.monotonic()
 groups=sorted({(e['part'],e['articulation']) for e in events})
 for part,artic in groups:
  subset=[e for e in events if e['part']==part and e['articulation']==artic]
  config={**spec['mix'][part],**maps['instruments'][spec['parts'][part]['instrument']]['articulations'][artic]}
  sfz=a.samples/config['sfz'];t=time.monotonic();report=engine.add_part(mix,{**spec,'duration':duration},part,artic,subset,config,sfz)
  report['render_seconds']=time.monotonic()-t;reports.append(report);print(json.dumps(report),flush=True)
 assert np.isfinite(mix).all();a.output.parent.mkdir(parents=True,exist_ok=True);wavfile.write(a.output,sr,mix)
 report={'engine':'sfizz','sample_rate':sr,'channels':2,'format':'FLOAT_32','duration':frames/sr,'frames':frames,'movement':spec['movement'],'note_events':len(events),'part_articulations':reports,'peak':float(np.max(np.abs(mix))),'render_seconds':time.monotonic()-began,'resampling_quality':8,'shared_timeline':True,'external_performance_audio_used':False,'subjective_audition_performed':False}
 a.output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(a.output,flush=True)
if __name__=='__main__':main()
