#!/usr/bin/env python3
"""New expressive Op21 realization from complete CC0 score events, no audio input."""
from pathlib import Path
import argparse,bisect,collections,json,math,re
import numpy as np
import soundfile as sf
import mido
DYN={'ppp':42,'pp':50,'p':59,'mp':68,'mf':78,'f':90,'ff':103,'fff':110}
MAPS={'flute':{'sus':'FluteSusNV','stac':'FluteStac'},'oboe':{'sus':'OboeSusNV','stac':'OboeStac'},'clarinet':{'sus':'ClarinetSus','stac':'ClarinetStac'},'bassoon':{'sus':'BassoonSus','stac':'BassoonStac'},'horn':{'sus':'FHornSus','stac':'FHornStac'},'trumpet':{'sus':'TrumpetSus','stac':'TrumpetStac'},'timpani':{'sus':'Timpani','stac':'Timpani','roll':'TimpaniRolls'},'violin':{'sus':'ViolinEnsSusVib','stac':'ViolinEnsSpic','pizz':'ViolinEnsPizz'},'viola':{'sus':'ViolaEnsSusVib','stac':'ViolaEnsSpic','pizz':'ViolaEnsPizz'},'cello':{'sus':'CelloEnsSusVib','stac':'CelloEnsSpic','pizz':'CelloEnsPizz'},'bass':{'sus':'ContrabassSusNV','stac':'ContrabassSpic','pizz':'ContrabassPizz'}}
PAN=[-.22,-.05,.12,.27,-.10,.07,.15,.30,-.30,-.14,-.06,.10,.22,-.48,-.22,.08,.29,.43]
TARGET={'flute':-33,'oboe':-33,'clarinet':-33,'bassoon':-33.5,'horn':-36,'trumpet':-38,'timpani':-39,'violin':-29.5,'viola':-31,'cello':-30.5,'bass':-32}
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
def regions(path):
 text=path.read_text();base=re.search(r'default_path=([^\n]+)',text).group(1).strip();state={};out=[]
 chunks=re.split(r'(<(?:global|group|region)>)',text)
 for k in range(1,len(chunks),2):
  tag,ch=chunks[k],chunks[k+1];items={}
  for line in ch.splitlines():
   line=line.split('//')[0].strip()
   if '=' in line:
    key,value=line.split('=',1);items[key.strip()]=value.strip()
  if tag=='<global>':state=items
  elif tag=='<group>':state={k:v for k,v in state.items() if k not in ('seq_position','seq_length')};state.update(items)
  else:
   x={**state,**items};x['path']=base+x['sample'];out.append(x)
 return out

def midi(spec,path):
 mid=mido.MidiFile(type=1,ticks_per_beat=1000);t=mido.MidiTrack();mid.tracks.append(t);t.append(mido.MetaMessage('set_tempo',tempo=1000000,time=0))
 for track_index,pid in enumerate(spec['parts']):
  channel=[0,1,2,3,4,5,6,7,8,10,11,12,13,14,15][track_index%15]
  tr=mido.MidiTrack();mid.tracks.append(tr);tr.append(mido.MetaMessage('midi_port',port=track_index//15,time=0));tr.append(mido.MetaMessage('track_name',name=spec['parts'][pid]['name'],time=0));rows=[]
  for e in spec['events']:
   if e['part']==pid:rows.extend([(round(e['start']*1000),1,mido.Message('note_on',channel=channel,note=e['pitch'],velocity=e['velocity'])),(round((e['start']+e['duration'])*1000),0,mido.Message('note_off',channel=channel,note=e['pitch'],velocity=0))])
  last=0
  for tick,_,msg in sorted(rows,key=lambda r:(r[0],r[1])):msg.time=tick-last;tr.append(msg);last=tick
  tr.append(mido.MetaMessage('end_of_track',time=max(0,round(spec['duration']*1000)-last)))
 mid.save(path)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--score',type=Path,required=True);ap.add_argument('--samples',type=Path,required=True);ap.add_argument('--calibration',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cal=json.loads(a.calibration.read_text())['rows'];cal={r['map']:r for r in cal if r['velocity']==88}
 reg={name:regions(a.samples/(name+'.sfz')) for mapping in MAPS.values() for name in mapping.values()};formats={};instrumentmap={'instruments':{}}
 for inst,maps in MAPS.items():
  art={}
  for key,name in maps.items():
   release=(.09 if key=='stac' else .20) if inst!='timpani' else .42
   row=cal[name+'.sfz'];ceiling=(-18 if key=='pizz' else -20 if key=='stac' else -24 if key=='roll' else -19)
   gain=min(TARGET[inst]-row['window_rms_dbfs'],ceiling-row['peak_dbfs']);art[key]={'sfz':name+'.sfz','gain_db':round(float(np.clip(gain,-18,24)),3),'release_seconds':release}
  instrumentmap['instruments'][inst]={'articulations':art}
 dump(a.out/'instrument-map.json',instrumentmap)
 audit=[]
 for movement in range(1,5):
  notes=json.loads((a.score/f'movement-{movement}-notes.json').read_text());dirs=json.loads((a.score/f'movement-{movement}-directions.json').read_text());st=json.loads((a.score/f'movement-{movement}-structure.json').read_text());total=st['total_quarters'];parts={p['id']:p for p in st['parts']}
  ts={0.:{1:44,2:60,3:324,4:31.5}[movement]}
  for d in dirs:
   if d['part_id']=='P1':
    for s in d['sound']:
     if 'tempo'in s:ts[d['quarter']]=float(s['tempo'])
  tx=sorted(ts);grid=np.linspace(0,total,math.ceil(total*128)+1);bpms=np.array([ts[tx[bisect.bisect_right(tx,q)-1]] for q in grid])
  # Shared subtle phrase breathing; musical marks govern each tempo section.
  bpms*=1+.007*np.sin(2*np.pi*grid/16)+.003*np.sin(2*np.pi*grid/4)
  for b in st['play_order']:
   q=b['start_quarter'];length=b['duration_quarters'];bar=int(b['bar'])
   if bar in (int(st['written_bars'][-1]['bar']),):
    sel=(grid>=q)&(grid<=q+length);bpms[sel]*=np.linspace(1,.86,int(sel.sum()))
  # Fermatas lengthen the shared clock, keeping every section together.
  seen=set()
  for n in notes:
   if n['fermatas']:
    q=n['onset_quarter'];end=q+n['gate_quarters'];key=(round(q,6),round(end,6))
    if key not in seen:
     seen.add(key);bpms[(grid>=q)&(grid<end)]*=.60 if movement==4 and q<14 else .72
  times=np.zeros_like(grid);times[1:]=np.cumsum((60/bpms[:-1]+60/bpms[1:])*.5*np.diff(grid));at=lambda q:float(np.interp(q,grid,times))
  # Ordinary dynamics and bowing instructions only; no research labels/colors.
  pd=collections.defaultdict(list)
  for d in dirs:
   pd[d['part_id']].append(d)
  controls={};pizz={};accents={};wedges={}
  for pid in parts:
   marks={0.:68 if movement in (1,4) else 59};pz={0.:False};ac={};wed=[];seen_dirs=set()
   for d in sorted(pd[pid],key=lambda d:d['written_quarter']):
    q=d['written_quarter']
    for t in d['types']:
     key=(q,str(t))
     if key in seen_dirs:continue
     seen_dirs.add(key)
     if t['tag']=='dynamics':
      for val in t['values']:
       if val in DYN:marks[q]=DYN[val]
       elif val=='fp':marks[q+.16]=59;ac[q]=22
       elif val in ('sf','sfz','sfp','rf','rfz','fz'):ac[q]=17
     elif t['tag']=='words':
      w=(t.get('text') or '').lower()
      if 'pizz'in w:pz[q]=True
      elif 'arco'in w:pz[q]=False
     elif t['tag']=='wedge':wed.append((q,t['attributes']))
   controls[pid]=(sorted(marks),marks);pizz[pid]=(sorted(pz),pz);accents[pid]=ac
   active={};segments=[]
   for q,w in wed:
    number=w.get('number','1');kind=w.get('type')
    if kind in ('crescendo','diminuendo'):active[number]=(q,kind)
    elif kind=='stop' and number in active:
     start,kind=active.pop(number);segments.append((start,q,kind))
   wedges[pid]=segments
  def dynamic(pid,wq):
   xs,vals=controls[pid];v=vals[xs[bisect.bisect_right(xs,wq)-1]]
   for lo,hi,kind in wedges[pid]:
    if lo<=wq<=hi and hi>lo:v+=(12 if kind=='crescendo' else -12)*(wq-lo)/(hi-lo)
   return max(35,min(112,v))
  curves={};mix={};source_by_id={n['id']:n for n in notes}
  for pid,p in parts.items():
   inst=p['instrument'];idx=int(pid[1:])-1;mix[pid]={'pan':PAN[idx],'width':.38 if inst in ('violin','viola','cello','bass') else .18,'gain_db':0}
   arr=[]
   for b in st['play_order']:
    orig=st['written_bars'][b['measure_index']]['written_start_quarter'];q=b['start_quarter'];ln=b['duration_quarters']
    for z in np.arange(0,ln,.5):
     dyn=dynamic(pid,orig+z);amp=10**((dyn-88)*.09/20)*(1+.025*math.sin(2*math.pi*(q+z)/16))
     arr.append([round(.55+at(q+z),6),round(amp,6)])
   arr.append([.55+float(times[-1])+6,arr[-1][1]]);curves[pid]=arr
  events=[];derived=collections.Counter();coverage={};failures=[];slurstate=collections.defaultdict(set)
  for n in sorted(notes,key=lambda x:(x['onset_quarter'],x['grace_quarter'],x['part_id'],x['source_index'])):
   pid=n['part_id'];inst=n['instrument'];q=n['onset_quarter'];g=n['gate_quarters'];wq=n['written_quarter'];pitch=n['pitch'];dyn=dynamic(pid,wq)
   arts=set(n['articulations']);state=slurstate[pid,n['voice']]
   for s in n['slurs']:
    if s['type']=='start':state.add(s.get('number','1'))
   slurred=bool(state)
   for s in n['slurs']:
    if s['type']=='stop':state.discard(s.get('number','1'))
   vel=round(np.clip(dyn+accents[pid].get(wq,0)+1.6*math.sin(q*.67+pitch*.11),36,118))
   if 'accent'in arts:vel=min(121,vel+9)
   if 'strong-accent'in arts:vel=min(123,vel+14)
   start=.55+at(q)+.003*math.sin(int(pid[1:])*1.61);duration=at(min(total,q+g))-at(q)
   grace=n['grace'];segments=[];kind='anchor'
   trem=next((o for o in n['ornaments'] if o['tag']=='tremolo'),None);trill=any(o['tag']=='trill-mark'for o in n['ornaments'])
   if grace:
    count=n.get('grace_count',1);rank=n.get('grace_rank',0);gap=.055 if movement!=3 else .035;start-=gap*(count-rank);duration=gap*.88;segments=[(start,duration,pitch)];kind='grace'
   elif inst=='timpani' and (trill or trem):segments=[(start,max(.04,duration),pitch)];kind='timpani_roll'
   elif trem:
    step=4/(2**(2+int(trem['text'])));count=max(1,round(g/step));step=g/count
    for j in range(count):
     t=.55+at(q+j*step);dt=at(min(total,q+(j+1)*step))-at(q+j*step);segments.append((t,max(.018,dt*.82),pitch))
    kind='measured_tremolo'
   elif trill:
    step=max(.055,min(.095,duration/4));count=max(3,round(duration/step));dt=duration/count
    scale=[0,2,4,5,7,9,11];fifths=n['key_fifths'];sharps='FCGDAEB';flats='BEADGCF';letter='CDEFGAB';upper=letter[(letter.index(n['written_step'])+1)%7];alter=(1 if upper in sharps[:max(0,fifths)] else -1 if upper in flats[:max(0,-fifths)] else 0)
    if any(o['tag']=='accidental-mark' and o['text']=='natural' for o in n['ornaments']):alter=0
    octave=n['written_octave']+(n['written_step']=='B');aux=12*(octave+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[upper]+alter+n['transpose_semitones']
    for j in range(count):segments.append((start+j*dt,dt*.90,pitch if j%2==0 else aux))
    kind='written_trill'
   else:segments=[(start,max(.025,duration),pitch)]
   for j,(t,dur,p) in enumerate(segments):
    pzxs,pz=pizz[pid];ispizz=pz[pzxs[bisect.bisect_right(pzxs,wq)-1]] and 'pizz' in MAPS[inst]
    artic='roll' if kind=='timpani_roll' else 'pizz' if ispizz else 'stac' if (kind=='measured_tremolo' or 'staccato'in arts or 'staccatissimo'in arts or (dur<.21 and not slurred)) else 'sus'
    factor=.48 if 'staccatissimo'in arts else .62 if 'staccato'in arts else .98 if slurred else .88
    if kind in ('measured_tremolo','written_trill','grace'):factor=1
    if inst=='timpani' and artic!='roll':dur=min(dur,.34);factor=1
    gate=max(.018,dur*factor)
    if artic=='stac':gate=min(gate,.28)
    name=MAPS[inst][artic]
    matches=[x for x in reg[name] if int(x.get('lokey','0'))<=p<=int(x.get('hikey','127')) and int(x.get('lovel','0'))<=vel<=int(x.get('hivel','127'))]
    if not matches:
     failures.append({'id':n['id'],'map':name,'pitch':p,'velocity':vel,'reason':'out_of_map'});continue
    durations=[]
    for x in matches:
     path=x['path']
     if path not in formats:
      info=sf.info(a.samples/path);formats[path]=(info.frames/info.samplerate)
     available=formats[path]/2**((p-float(x['pitch_keycenter']))/12)
     durations.append(available)
    if artic in ('sus','roll') and inst!='timpani' and gate>min(durations)-.05:
     failures.append({'id':n['id'],'map':name,'pitch':p,'gate':gate,'available':min(durations),'reason':'finite_sustain'});continue
    ev={'source_id':n['id'],'source_ids':n['source_ids'],'start':round(max(.05,t),6),'duration':round(gate,6),'pitch':int(p),'velocity':int(vel),'part':pid,'articulation':artic,'realization':kind,'derived_attack':j>0}
    events.append(ev);coverage[n['id']]=coverage.get(n['id'],0)+1
   if kind not in ('anchor','grace'):derived[kind]+=max(0,len(segments)-1)
  # A new attack damps a preceding same-key gate in the same scored part.
  groups=collections.defaultdict(list)
  for e in events:groups[e['part'],e['pitch']].append(e)
  shortened=0
  for group in groups.values():
   group.sort(key=lambda e:e['start'])
   for e,f in zip(group,group[1:]):
    if e['start']+e['duration']>f['start']-.004:
     e['duration']=max(.012,f['start']-e['start']-.004);shortened+=1
  report={'movement':movement,'source_anchors':len(notes),'covered_anchors':len(coverage),'events':len(events),'derived_attacks':dict(derived),'source_graces':sum(n['grace']for n in notes),'missing_source_ids':[n['id']for n in notes if n['id']not in coverage],'sample_coverage_failures':failures,'same_key_gates_shortened':shortened,'subjective_audition':False}
  dump(a.out/f'movement-{movement}-coverage.json',report)
  if failures or len(coverage)!=len(notes):print(json.dumps({'movement':movement,'failures':len(failures),'examples':failures[:8]}));continue
  duration=math.ceil((.55+float(times[-1])+6)*24)/24
  spec={'movement':movement,'title':st['title'],'sample_rate':48000,'duration':duration,'notated_end_seconds':.55+float(times[-1]),'parts':parts,'mix':mix,'events':events,'expression_curves':curves,'source_file':f'movement-{movement}-notes.json','editorial_tempo':'Source tempo changes with shared phrase breathing, source fermatas and a modest final cadence. No target duration input.'}
  dump(a.out/f'movement-{movement}-performance.json',spec);midi(spec,a.out/f'movement-{movement}.midi');audit.append(report)
  print(json.dumps({'movement':movement,'seconds':duration,'events':len(events),'anchors':len(coverage),'derived':dict(derived)}),flush=True)
 dump(a.out/'coverage.json',audit)
if __name__=='__main__':main()
