from pathlib import Path
import argparse,json,subprocess
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--scene',type=Path,required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c=json.loads(a.config.read_text());w,h=960,540;size=w*h
proc=subprocess.Popen(['ffmpeg','-v','error','-xerror','-i',str(a.scene),'-vf','scale=960:540,format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
frames={};adj=[];first=prev=None;i=0
while True:
 raw=proc.stdout.read(size)
 if not raw:break
 assert len(raw)==size
 x=np.frombuffer(raw,np.uint8).reshape(h,w).astype(np.float32)
 if first is None:first=x.copy()
 if prev is not None:adj.append(float(np.mean(np.abs(x-prev))))
 if i in (0,24*15,round(6.8*24),round(7.1*24)):frames[i]=x.copy()
 prev=x;i+=1
err=proc.stderr.read().decode();assert proc.wait()==0,err;assert i==1440,i
seam=float(np.mean(np.abs(prev-first)));limit=max(.15,4*float(np.median(adj)));assert seam<=limit,(seam,limit)
a0=frames[0];b=frames[360];protected={}
for name,(x,y,ww,hh) in c['protected_regions_1920x1080'].items():
 z=np.abs(a0[y//2:(y+hh)//2,x//2:(x+ww)//2]-b[y//2:(y+hh)//2,x//2:(x+ww)//2]);v=float(z.mean());assert v<.2,(name,v);protected[name]=v
fol=[]
for d in c['foliage_patches']:
 x,y,ww,hh=d['rectangle'];v=float(np.abs(a0[y//2:(y+hh)//2,x//2:(x+ww)//2]-b[y//2:(y+hh)//2,x//2:(x+ww)//2]).mean());assert v>.1,v;fol.append(v)
r0=frames[round(6.8*24)];r1=frames[round(7.1*24)];water=float(np.abs(r0[440:495,70:190]-r1[440:495,70:190]).sum());assert water>1,water
report={'full_decode':'passed','frames':i,'duration_seconds':60,'loop_boundary_gray_mae':seam,'limit':limit,'protected_region_mae':protected,'fern_motion_mae':fol,'water_effect_change_sum':water,'characters_animated':False,'ambient_audio':False,'subjective_audition_performed':False};a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
