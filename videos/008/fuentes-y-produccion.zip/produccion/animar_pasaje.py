#!/usr/bin/env python3
"""New 008 village passage: small pot-leaf sway and sparse drips/ripples.

FFmpeg video effects only. The static generated artwork is not overwritten.
The animals, architecture and camera remain still. Water effects are original
vector VFX; this is not a recorded fluid simulation and adds no ambient sound.
"""
from pathlib import Path
import argparse,json,math,os,subprocess

W,H,FPS,PERIOD=1920,1080,24,60

def stamp(t):
 n=round(t*100)
 return f'{n//360000}:{n//6000%60:02d}:{n//100%60:02d}.{n%100:02d}'

def event(start,end,text,layer=1):
 return f'Dialogue: {layer},{stamp(start)},{stamp(end)},Water,,0,0,0,,{text}'

def make_water(config):
 header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Water,DejaVu Sans,12,&H00CEDBDE,&H00FFFFFF,&H00CEDBDE,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 rows=[]
 # A tiny original tapered water drop, around2x9scriptpixels atfullresolution.
 drop='m 0 -5 b -1 -2 -1 0 -1 2 b -1 4 1 4 1 2 b 1 0 1 -2 0 -5'
 # Unit circle asBezier; scaled to an elliptical ripple with transparent fill.
 circle='m 1 0 b 1 0.5523 0.5523 1 0 1 b -0.5523 1 -1 0.5523 -1 0 b -1 -0.5523 -0.5523 -1 0 -1 b 0.5523 -1 1 -0.5523 1 0'
 for d in config['drops']:
  start=d['start'];fall=d.get('fall_seconds',.65);end=start+fall
  x0,y0=d['from'];x1,y1=d['impact'];steps=12
  for k in range(steps):
   f0=k/steps;f1=(k+1)/steps
   # Accelerating trajectory; a small nonzero initial speed avoids a hovering drop.
   yA=y0+(y1-y0)*(.22*f0+.78*f0*f0)
   yB=y0+(y1-y0)*(.22*f1+.78*f1*f1)
   xA=x0+(x1-x0)*f0;xB=x0+(x1-x0)*f1
   ms=round(fall/steps*1000)
   tag=(f'{{\\an7\\p1\\bord0\\shad0\\blur0.32\\1c&H{d.get("color","CEDBDE")}&'
        f'\\1a&H{d.get("alpha","70")}&\\fscx100\\fscy{100+65*f0:.2f}'
        f'\\t(0,{ms},\\fscy{100+65*f1:.2f})\\move({xA:.3f},{yA:.3f},{xB:.3f},{yB:.3f})}}')
   rows.append(event(start+fall*f0,start+fall*f1,tag+drop))
  for ring,delay in enumerate((0.,.23)):
   t=end+delay;length=1.8-ring*.12
   rx0=2.5;ry0=.7;rx1=d.get('ripple_radius',32.)*(1.-ring*.10);ry1=rx1*d.get('ripple_flatness',.22)
   # Absolute border is deliberately thin; rings fade before the next event.
   a0='72' if ring==0 else 'A0'
   tag=(f'{{\\an7\\p1\\pos({x1:.3f},{y1:.3f})\\shad0\\blur0.35\\bord0.55'
        f'\\1a&HFF&\\3c&H{d.get("ripple_color","B9CED3")}&\\3a&H{a0}&'
        f'\\fscx{rx0*100:.3f}\\fscy{ry0*100:.3f}'
        f'\\t(0,{round(length*1000)},\\fscx{rx1*100:.3f}\\fscy{ry1*100:.3f}\\3a&HFF&)}}')
   rows.append(event(t,t+length,tag+circle))
 return header+'\n'.join(rows)+'\n'

def filters(ass,patches):
 split=''.join(f'[p{i}]' for i in range(len(patches)))
 fs=['[0:v]scale=1920:1080:force_original_aspect_ratio=increase:flags=lanczos,crop=1920:1080,setsar=1,format=yuv420p,'+f'split={len(patches)+1}[bg]{split}']
 previous='bg'
 for k,p in enumerate(patches):
  x,y,w,h=p['rectangle'];cx,cy,rx,ry=p['mask_center_radii']
  fs += [f'[p{k}]crop={w}:{h}:{x}:{y}[fol{k}]',
   f"nullsrc=s={w//4}x{h//4}:r=24:d=60,format=gray,geq=lum='128+1.6*sin(2*PI*T/20+{k*.7})+0.5*sin(2*PI*(Y/41+T/30))',scale={w}:{h}:flags=bilinear[x{k}]",
   f"nullsrc=s={w//4}x{h//4}:r=24:d=60,format=gray,geq=lum='128+1.2*sin(2*PI*T/30+{.6+k*.7})+0.4*cos(2*PI*(X/53+T/20))',scale={w}:{h}:flags=bilinear[y{k}]",
   f'[fol{k}][x{k}][y{k}]displace=edge=smear,format=yuva420p,'+f"geq=lum='lum(X,Y)':cb='cb(X,Y)':cr='cr(X,Y)':a='{p.get('alpha',210)}*exp(-pow((X-{cx})/{rx},4)-pow((Y-{cy})/{ry},4))'[fx{k}]",
   f'[{previous}][fx{k}]overlay={x}:{y}[stage{k}]']
  previous=f'stage{k}'
 fs.append(f"[{previous}]ass=filename='{ass.as_posix()}',format=yuv420p[out]")
 return ';'.join(fs)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--image',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--seconds',type=float,default=60);ap.add_argument('--qp',type=int,default=1)
 a=ap.parse_args();a.output.parent.mkdir(parents=True,exist_ok=True);config=json.loads(a.config.read_text());ass=a.output.parent/'gotas-y-ondas.ass';ass.write_text(make_water(config))
 cache=a.output.parent/'font-cache';cache.mkdir(exist_ok=True)
 cmd=['ffmpeg','-hide_banner','-loglevel','warning','-nostdin','-y','-filter_complex_threads','2','-loop','1','-framerate','24','-i',str(a.image),'-filter_complex',filters(ass,config['foliage_patches']),'-map','[out]','-an','-t',str(a.seconds),'-c:v','libx264','-threads','3','-preset','fast','-qp',str(a.qp),'-profile:v','high','-g','240','-keyint_min','240','-sc_threshold','0','-flags','+cgop','-pix_fmt','yuv420p','-movflags','+faststart',str(a.output)]
 subprocess.run(cmd,check=True,env=dict(os.environ,XDG_CACHE_HOME=str(cache)))
 config.update({'period_seconds':60,'fps':24,'width':1920,'height':1080,'source_artwork':a.image.name,'qp':a.qp,'characters_animated':False,'camera_animated':False,'architecture_animated':False,'ambient_audio':False,'water_effects':'Original vector drops and synchronized expanding elliptical rings; not a recorded water simulation'})
 (a.output.parent/'escena-config.json').write_text(json.dumps(config,indent=2)+'\n');print(a.output)
if __name__=='__main__':main()
