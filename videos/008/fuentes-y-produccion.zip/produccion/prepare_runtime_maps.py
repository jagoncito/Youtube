from pathlib import Path
import argparse,re,shutil
p=argparse.ArgumentParser();p.add_argument('--samples',type=Path,required=True);a=p.parse_args();original=a.samples/'original-sfz';original.mkdir(exist_ok=True)
for f in a.samples.glob('*.sfz'):
 if not (original/f.name).exists():shutil.copyfile(f,original/f.name)
 s=f.read_text().replace('\\','/')
 if f.name in ('ViolinEnsSusVib.sfz','ViolinEnsSpic.sfz'):
  top=max(map(int,re.findall(r'(?m)^hikey=(\d+)',s)))
  if top<91:s=re.sub(r'(?m)^hikey='+str(top)+r'$', 'hikey=91',s)
 f.write_text(s)
