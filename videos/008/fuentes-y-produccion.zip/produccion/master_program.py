#!/usr/bin/env python3
"""One complete Op21, common mastering gain and measured natural endings."""
from pathlib import Path
import argparse,json,math
import numpy as np
import soundfile as sf
from scipy import signal

def rms(a):return float(np.sqrt(np.mean(a.astype(np.float64)**2)))
def main():
 p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();sr=48000;prepared=[];peak=0
 rng=np.random.default_rng(21008);length=round(sr*2.8);t=np.arange(length)/sr;irs=[]
 for ch in (0,1):
  ir=np.zeros(length,np.float32);idx=rng.choice(np.arange(round(.055*sr),length),3400,replace=False)
  ir[idx]=rng.choice([-1.,1.],len(idx))*np.exp(-6.9078*t[idx]/1.8)
  ir=signal.sosfilt(signal.butter(2,4700,fs=sr,output='sos'),ir);ir/=np.sqrt(np.sum(ir*ir));irs.append(ir)
 for m in range(1,5):
  x,rate=sf.read(a.input_dir/f'movement-{m}.float.wav',dtype='float32');assert rate==sr and x.shape[1]==2 and np.isfinite(x).all()
  dry=signal.sosfilt(signal.butter(2,24,fs=sr,btype='highpass',output='sos'),x,axis=0).astype(np.float32);wet=np.zeros_like(dry)
  for c in (0,1):
   wet[:,c]=signal.oaconvolve(.91*dry[:,c]+.09*dry[:,1-c],irs[c],mode='full')[:len(dry)]*.10
   for delay,amount in ((.022,.025),(.039,.019),(.067,.012)):
    k=round((delay+.002*c)*sr);wet[k:,c]+=dry[:-k,1-c]*amount
  y=dry+wet
  for start in range(0,len(y),sr*12):
   b=y[max(0,start-32):min(len(y),start+sr*12+32)];peak=max(peak,float(np.max(np.abs(signal.resample_poly(b,4,1,axis=0)))))
  path=a.input_dir/f'movement-{m}.room.float.wav';sf.write(path,y,sr,subtype='FLOAT');prepared.append(path);del x,dry,wet,y
 gain=10**(-1.8/20)/peak;rows=[];offset=0;pauses=round(sr*1.1);a.output.parent.mkdir(parents=True,exist_ok=True)
 with sf.SoundFile(a.output,'w',samplerate=sr,channels=2,subtype='PCM_24') as out:
  for m,path in enumerate(prepared,1):
   y,_=sf.read(path,dtype='float32');y*=gain;spec=json.loads((a.input_dir/f'movement-{m}-performance.json').read_text());anchor=max(spec['notated_end_seconds'],max(e['start']+e['duration'] for e in spec['events']))
   window=round(sr*.1);scan=[(k,rms(y[k:k+window])) for k in range(round(anchor*sr),len(y)-window+1,window)];first=None
   for i,(k,v) in enumerate(scan):
    if len(scan)-i>=5 and all(z<1e-4 for _,z in scan[i:]):first=k/sr;break
   if first is None:raise RuntimeError(f'Movement{m}: extend release buffer')
   frames=round(math.ceil((first+1.05)*24)/24*sr);assert frames<=len(y),(m,frames,len(y));y=y[:frames].copy();tail=float(np.max(np.abs(y[-9600:])));assert tail<.0002,(m,tail)
   y[-9600:]*=np.linspace(1,0,9600,dtype=np.float32)[:,None]
   rows.append({'movement':m,'title':spec['title'],'start_seconds':offset/sr,'duration_seconds':frames/sr,'notated_end_local':spec['notated_end_seconds'],'last_note_off_local':anchor,'stable_below_minus80_local':first,'final_200ms_peak_before_fade':tail,'note_events':len(spec['events']),'pause_after_seconds':1.1 if m<4 else 0})
   out.write(y);offset+=frames
   if m<4:out.write(np.zeros((pauses,2),np.float32));offset+=pauses
 report={'sample_rate':sr,'channels':2,'subtype':'PCM_24','frames':offset,'duration_seconds':offset/sr,'common_gain_db':20*math.log10(gain),'target_true_peak_dbtp':-1.8,'compression':False,'limiter':False,'external_recording_used':False,'repeated_program':False,'room':'New deterministic mathematical stereo room, RT60~1.8s, wet .10 plus quiet early reflections','movement_sequence':rows,'subjective_audition_performed':False}
 a.output.with_suffix('.mastering.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'seconds':offset/sr,'gain_db':report['common_gain_db'],'chapters':[(r['start_seconds'],r['title']) for r in rows]},indent=2))
if __name__=='__main__':main()
