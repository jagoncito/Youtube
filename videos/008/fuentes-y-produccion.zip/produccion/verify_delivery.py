from pathlib import Path
import argparse,collections,json,math,subprocess
import numpy as np
import soundfile as sf
import mido
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--score',type=Path,required=True);p.add_argument('--performance',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();r=a.root
report={'scope':'Technical verification; no subjective audition performed','source':[],'wav':{},'mp4':{}}
for m in range(1,5):
 notes=json.loads((a.score/f'movement-{m}-notes.json').read_text());s=json.loads((a.performance/f'movement-{m}-performance.json').read_text());c=json.loads((a.performance/f'movement-{m}-coverage.json').read_text());rr=json.loads((a.performance/f'movement-{m}.float.json').read_text());ids={x['id']:x for x in notes};groups=collections.defaultdict(list)
 for e in s['events']:groups[e['source_id']].append(e)
 assert set(groups)==set(ids) and not c['missing_source_ids'] and not c['sample_coverage_failures']
 for sid,es in groups.items():
  assert es[0]['pitch']==ids[sid]['pitch'],sid
  assert all(e['pitch']==ids[sid]['pitch'] for e in es) if es[0]['realization']!='written_trill' else True
 assert rr['note_events']==len(s['events'])==sum(x['musical_events'] for x in rr['part_articulations'])
 assert {x['part'] for x in rr['part_articulations']}=={n['part_id'] for n in notes}
 assert all(x['peak']>0 and x['regions']>0 and x['loaded_samples']>0 for x in rr['part_articulations'])
 mid=mido.MidiFile(a.performance/f'movement-{m}.midi');observed=[]
 for tr in mid.tracks[1:]:
  ticks=0;active={};label=None
  for e in tr:
   ticks+=e.time
   if e.type=='track_name':label=e.name
   if e.type=='note_on' and e.velocity:
    assert e.note not in active,(m,label,e.note,'overlap');active[e.note]=(ticks,e.velocity)
   elif e.type=='note_off' or (e.type=='note_on' and not e.velocity):
    assert e.note in active;on,v=active.pop(e.note);observed.append((label,e.note,v,on,ticks))
  assert not active
 expected=[(s['parts'][e['part']]['name'],e['pitch'],e['velocity'],round(e['start']*1000),round((e['start']+e['duration'])*1000)) for e in s['events']]
 assert sorted(observed)==sorted(expected),(m,'MIDI mismatch')
 report['source'].append({'movement':m,'anchors':len(notes),'rendered_attacks':len(s['events']),'all_sounding_parts_rendered':True,'parts_in_score':18,'active_parts':len({n['part_id']for n in notes}),'source_and_ornament_coverage':'passed','midi_pairing_and_timing':'passed'})
audio=r/'beethoven-symphony-no1.wav';info=sf.info(audio);assert (info.samplerate,info.channels,info.subtype)==(48000,2,'PCM_24')
peak=0.;clipped=0;dc=np.zeros(2);count=0
for block in sf.blocks(audio,blocksize=65536,dtype='float64',always_2d=True):
 assert np.isfinite(block).all();peak=max(peak,float(np.max(np.abs(block))));clipped+=int(np.count_nonzero(np.abs(block)>=.99999));dc+=block.sum(0);count+=len(block)
assert clipped==0 and peak<.9 and np.max(np.abs(dc/count))<.001
master=json.loads((r/'beethoven-symphony-no1.mastering.json').read_text());assert info.frames==master['frames'];joins=[]
with sf.SoundFile(audio) as w:
 w.seek(w.frames-4800);last=w.read(dtype='float64');assert np.max(np.abs(last))<.0001
 for x in master['movement_sequence'][1:]:
  frame=round(x['start_seconds']*48000);w.seek(frame-1);b=w.read(2,dtype='float64');jump=float(np.max(np.abs(b[1]-b[0])));assert jump<.001;joins.append(jump)
cmd=['ffmpeg','-hide_banner','-nostats','-i',str(audio),'-af','loudnorm=I=-18:TP=-1.5:LRA=11:print_format=json','-f','null','-'];z=subprocess.run(cmd,capture_output=True,text=True,check=True).stderr;measured=json.JSONDecoder().raw_decode(z[z.rfind('{'):])[0];assert float(measured['input_tp'])<=-1
report['wav']={'frames':info.frames,'seconds':info.duration,'sample_peak':peak,'clipped_samples':clipped,'dc_offset':(dc/count).tolist(),'true_peak_dbtp':float(measured['input_tp']),'integrated_lufs':float(measured['input_i']),'loudness_range_lu':float(measured['input_lra']),'final_100ms_peak':float(np.max(np.abs(last))),'movement_boundary_jumps':joins}
print('Score, MIDI and WAV passed',flush=True)
video=r/'beethoven-symphony-no1.mp4';meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(video)]));vs=next(x for x in meta['streams'] if x['codec_type']=='video');au=next(x for x in meta['streams'] if x['codec_type']=='audio');assert (vs['codec_name'],vs['width'],vs['height'],vs['r_frame_rate'],vs['pix_fmt'],au['codec_name'],int(au['sample_rate']),au['channels'])==('h264',1920,1080,'24/1','yuv420p','aac',48000,2)
assert abs(float(meta['format']['duration'])-info.duration)<.125;assert abs(float(au['duration'])-info.duration)<.002
assert len(meta['chapters'])==4
for ch,row in zip(meta['chapters'],master['movement_sequence']):assert abs(float(ch['start_time'])-row['start_seconds'])<.002
z=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(video),'-f','null','-'],capture_output=True,text=True,check=True);assert not z.stderr,z.stderr
proc=subprocess.Popen(['ffmpeg','-v','error','-xerror','-i',str(video),'-map','0:a:0','-f','f32le','-acodec','pcm_f32le','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);sums=np.zeros(7,dtype=np.float64)
with sf.SoundFile(audio) as w:
 left=w.frames
 while left:
  n=min(left,65536);data=proc.stdout.read(n*8);assert len(data)==n*8;x=w.read(n,dtype='float64',always_2d=True).ravel();y=np.frombuffer(data,dtype='<f4').astype(np.float64);sums +=[len(x),x.sum(),y.sum(),x@x,y@y,x@y,(x-y)@(x-y)];left-=n
extra=proc.stdout.read();err=proc.stderr.read().decode();assert proc.wait()==0,err;assert len(extra)<=8192
n,sx,sy,xx,yy,xy,error=sums;corr=(xy-sx*sy/n)/np.sqrt((xx-sx*sx/n)*(yy-sy*sy/n));snr=10*np.log10(xx/max(error,1e-30));assert corr>.98 and snr>18,(corr,snr)
report['mp4']={'full_decode':'passed','seconds':float(meta['format']['duration']),'audio_seconds':float(au['duration']),'aac_pcm_correlation':float(corr),'aac_pcm_snr_db':float(snr),'chapters':meta['chapters'],'video_codec':'H264 High 1080p24 yuv420p','audio_codec':'AAC stereo 48kHz'}
a.out.write_text(json.dumps(report,indent=2)+'\n');print('Full MP4 and AAC/PCM correspondence passed',flush=True)
