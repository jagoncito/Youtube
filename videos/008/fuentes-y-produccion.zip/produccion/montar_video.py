from pathlib import Path
import argparse,json,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--scene',type=Path,required=True);p.add_argument('--audio',type=Path,required=True);p.add_argument('--master',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();m=json.loads(a.master.read_text());duration=m['duration_seconds']
lines=[';FFMETADATA1','title=Beethoven: Symphony No. 1 | Jagoncito’s Cozy Village Evening','artist=Jagoncito','comment=Complete new sampled-orchestra digital realization. Four movements, no repeated full program. Original village artwork and environmental animation.','copyright=Beethoven historical composition; CC0 score and VSCO 2 CE samples. See accompanying source credits.']
for i,row in enumerate(m['movement_sequence']):
 end=m['movement_sequence'][i+1]['start_seconds'] if i<3 else duration
 lines+=['[CHAPTER]','TIMEBASE=1/1000',f"START={round(row['start_seconds']*1000)}",f'END={round(end*1000)}',f"title={i+1}. {row['title']}"]
with tempfile.TemporaryDirectory(prefix='symphony008-mux-') as td:
 meta=Path(td)/'chapters.txt';meta.write_text('\n'.join(lines)+'\n')
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-nostdin','-y','-stream_loop','-1','-i',str(a.scene),'-i',str(a.audio),'-f','ffmetadata','-i',str(meta),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-t',f'{duration:.9f}','-video_track_timescale','24000','-movflags','+faststart',str(a.output)],check=True)
print(a.output)
